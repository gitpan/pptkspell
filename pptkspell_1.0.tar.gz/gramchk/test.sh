python TextChecker.py -l hu -s 60 tests/hutest1.txt 
