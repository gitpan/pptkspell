tar cvf hurule.tar do_tar.sh hurule.txt posiperl.sh 
gzip -f hurule.tar
cp hurule.tar.gz /mnt/win_d/hattyu/tyuk/homepages/tkltrans.sourceforge/tklspell
cp hurule.tar.gz /mnt/floppy
